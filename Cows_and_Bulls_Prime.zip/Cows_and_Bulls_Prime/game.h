#ifndef GAME_H
#define GAME_H

#include <QMainWindow>
#include <QComboBox>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QStringList>

// Player class to manage points
class Player {
public:
    Player(const QString& name = "Player");
    QString getName() const;
    int getPoints() const;
    void addPoints(int points);
    bool usePoints(int points);
    void setPoints(int points);

private:
    QString name_;
    int points_;
};

// Game class to manage game logic
class Game {
public:
    Game();
    QString getSecretNumber() const;
    int getAttempts() const;
    std::pair<int, int> makeGuess(const QString& guess);
    QString getHint(int position) const;
    void reset();

private:
    QString secretNumber_;
    int attempts_;
    QString generateSecretNumber();
    bool isValidGuess(const QString& guess) const;
};

// MainWindow class for the GUI
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private:
    Game game_;
    Player player1_;
    Player player2_;
    Player* currentPlayer_;
    bool isTwoPlayerMode_;
    bool isPlayer1Turn_;

    // UI elements
    QComboBox* modeCombo_;
    QLineEdit* guessInput_;
    QPushButton* guessButton_;
    QPushButton* hintButton_;
    QPushButton* restartButton_;
    QLabel* statusLabel_;
    QLabel* pointsLabel_;
    QLabel* historyLabel_;
    QStringList history_;

    void setupUI();
    void updatePointsLabel();
    void savePoints();
    void loadPoints();

private slots:
    void onModeChanged(int index);
    void onGuess();
    void onHint();
    void onRestart();
};

#endif // GAME_H
