#include "game.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <random>
#include <set>

// Player class implementation
Player::Player(const QString& name) : name_(name), points_(0) {}

QString Player::getName() const { return name_; }

int Player::getPoints() const { return points_; }

void Player::addPoints(int points) { points_ += points; }

bool Player::usePoints(int points) {
    if (points_ >= points) {
        points_ -= points;
        return true;
    }
    return false;
}

void Player::setPoints(int points) { points_ = points; }

// Game class implementation
Game::Game() : secretNumber_(generateSecretNumber()), attempts_(0) {}

QString Game::getSecretNumber() const { return secretNumber_; }

int Game::getAttempts() const { return attempts_; }

std::pair<int, int> Game::makeGuess(const QString& guess) {
    if (guess.length() != 4 || !isValidGuess(guess)) {
        return {-1, -1}; // Invalid guess
    }
    attempts_++;
    int bulls = 0, cows = 0;
    for (int i = 0; i < 4; ++i) {
        if (guess[i] == secretNumber_[i]) {
            bulls++;
        } else if (secretNumber_.contains(guess[i])) {
            cows++;
        }
    }
    return {bulls, cows};
}

QString Game::getHint(int position) const {
    if (position >= 0 && position < 4) {
        return QString("Position %1 is %2").arg(position + 1).arg(secretNumber_[position]);
    }
    return "Invalid hint position";
}

void Game::reset() {
    secretNumber_ = generateSecretNumber();
    attempts_ = 0;
}

QString Game::generateSecretNumber() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 9);
    std::set<int> digits;
    while (digits.size() < 4) {
        digits.insert(dis(gen));
    }
    QString number;
    for (int digit : digits) {
        number += QString::number(digit);
    }
    return number;
}

bool Game::isValidGuess(const QString& guess) const {
    if (guess.length() != 4) return false;
    std::set<QChar> digits;
    for (QChar c : guess) {
        if (!c.isDigit()) return false;
        digits.insert(c);
    }
    return digits.size() == 4;
}

// MainWindow class implementation
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent),
    game_(),
    player1_("Player 1"),
    player2_("Player 2"),
    currentPlayer_(&player1_),
    isTwoPlayerMode_(false),
    isPlayer1Turn_(true) {
    loadPoints();
    setupUI();
    setWindowTitle("Bulls and Cows");
    resize(400, 500);
}

MainWindow::~MainWindow() {
    savePoints();
}

void MainWindow::setupUI() {
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);

    // Mode selection
    modeCombo_ = new QComboBox();
    modeCombo_->addItems({"Single Player", "Two Players"});
    mainLayout->addWidget(new QLabel("Select Mode:"));
    mainLayout->addWidget(modeCombo_);
    connect(modeCombo_, QOverload<int>::of(&QComboBox::activated), this, &MainWindow::onModeChanged);

    // Guess input and button
    guessInput_ = new QLineEdit();
    guessInput_->setPlaceholderText("Enter 4 unique digits");
    guessButton_ = new QPushButton("Guess");
    QHBoxLayout* inputLayout = new QHBoxLayout();
    inputLayout->addWidget(guessInput_);
    inputLayout->addWidget(guessButton_);
    mainLayout->addLayout(inputLayout);

    // Hint button
    hintButton_ = new QPushButton("Get Hint (50 points)");
    mainLayout->addWidget(hintButton_);

    // Restart button
    restartButton_ = new QPushButton("Restart Game");
    mainLayout->addWidget(restartButton_);

    // Status and points
    statusLabel_ = new QLabel("Enter your guess!");
    pointsLabel_ = new QLabel();
    updatePointsLabel();
    mainLayout->addWidget(statusLabel_);
    mainLayout->addWidget(pointsLabel_);

    // History
    historyLabel_ = new QLabel();
    mainLayout->addWidget(new QLabel("Guess History:"));
    mainLayout->addWidget(historyLabel_);
    mainLayout->addStretch();

    // Connect signals
    connect(guessButton_, &QPushButton::clicked, this, &MainWindow::onGuess);
    connect(hintButton_, &QPushButton::clicked, this, &MainWindow::onHint);
    connect(restartButton_, &QPushButton::clicked, this, &MainWindow::onRestart);
}

void MainWindow::onModeChanged(int index) {
    isTwoPlayerMode_ = (index == 1);
    game_.reset();
    history_.clear();
    historyLabel_->setText("");
    statusLabel_->setText(isTwoPlayerMode_ ? "Player 1's turn" : "Enter your guess!");
    currentPlayer_ = &player1_;
    isPlayer1Turn_ = true;
    updatePointsLabel();
}

void MainWindow::onGuess() {
    QString guess = guessInput_->text().trimmed();
    auto [bulls, cows] = game_.makeGuess(guess);
    if (bulls == -1) {
        QMessageBox::warning(this, "Invalid Guess", "Please enter 4 unique digits.");
        return;
    }

    QString result = QString("%1: %2 bulls, %3 cows").arg(guess).arg(bulls).arg(cows);
    if (isTwoPlayerMode_) {
        result = QString("%1 (%2): %3 bulls, %4 cows")
        .arg(guess)
            .arg(isPlayer1Turn_ ? "Player 1" : "Player 2")
            .arg(bulls)
            .arg(cows);
    }
    history_.prepend(result);
    historyLabel_->setText(history_.join("\n"));

    if (bulls == 4) {
        QString winner = isTwoPlayerMode_ ? (isPlayer1Turn_ ? "Player 1" : "Player 2") : "You";
        currentPlayer_->addPoints(100);
        updatePointsLabel();
        QMessageBox::information(this, "Victory!", QString("%1 won! Attempts: %2\n+100 points!").arg(winner).arg(game_.getAttempts()));
        game_.reset();
        history_.clear();
        historyLabel_->setText("");
        statusLabel_->setText(isTwoPlayerMode_ ? "Player 1's turn" : "Enter your guess!");
        isPlayer1Turn_ = true;
        currentPlayer_ = &player1_;
    } else {
        if (isTwoPlayerMode_) {
            isPlayer1Turn_ = !isPlayer1Turn_;
            currentPlayer_ = isPlayer1Turn_ ? &player1_ : &player2_;
            statusLabel_->setText(isPlayer1Turn_ ? "Player 1's turn" : "Player 2's turn");
        } else {
            statusLabel_->setText("Try again!");
        }
    }
    guessInput_->clear();
}

void MainWindow::onHint() {
    if (!currentPlayer_->usePoints(50)) {
        QMessageBox::warning(this, "Not Enough Points", "You need 50 points for a hint!");
        return;
    }
    static int hintPosition = 0;
    QString hint = game_.getHint(hintPosition % 4);
    hintPosition++;
    updatePointsLabel();
    QMessageBox::information(this, "Hint", hint);
}

void MainWindow::onRestart() {
    game_.reset();
    history_.clear();
    historyLabel_->setText("");
    statusLabel_->setText(isTwoPlayerMode_ ? "Player 1's turn" : "Enter your guess!");
    isPlayer1Turn_ = true;
    currentPlayer_ = &player1_;
}

void MainWindow::updatePointsLabel() {
    if (isTwoPlayerMode_) {
        pointsLabel_->setText(QString("Player 1: %1 points | Player 2: %2 points")
                                  .arg(player1_.getPoints())
                                  .arg(player2_.getPoints()));
    } else {
        pointsLabel_->setText(QString("Points: %1").arg(player1_.getPoints()));
    }
}

void MainWindow::savePoints() {
    QFile file("points.txt");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << player1_.getPoints() << "\n" << player2_.getPoints();
        file.close();
    } else {
        qDebug() << "Failed to save points to points.txt";
    }
}

void MainWindow::loadPoints() {
    QFile file("points.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        QStringList points = in.readAll().split("\n", Qt::SkipEmptyParts);
        if (points.size() >= 1) player1_.setPoints(points[0].toInt());
        if (points.size() >= 2) player2_.setPoints(points[1].toInt());
        file.close();
    } else {
        qDebug() << "Failed to load points from points.txt, starting with 0 points";
    }
}
